-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Хост: db8
-- Версия сервера: 9.2.0
-- Версия PHP: 8.2.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `newshop`
--
CREATE DATABASE IF NOT EXISTS `newshop` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `newshop`;

-- --------------------------------------------------------

--
-- Структура таблицы `category`
--

CREATE TABLE `category` (
  `id` int UNSIGNED NOT NULL,
  `parent_id` int UNSIGNED NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `category`
--

INSERT INTO `category` (`id`, `parent_id`, `slug`) VALUES
(1, 0, 'kompyutery'),
(2, 0, 'planshety'),
(3, 0, 'noutbuki'),
(4, 3, 'mac'),
(5, 3, 'windows'),
(6, 0, 'smartphones'),
(7, 0, 'kamery'),
(8, 6, 'smartphon_xiaomi'),
(9, 6, 'smartphon_huawei'),
(10, 6, 'smartphon_samsung'),
(11, 6, 'smartphon_iphone');

-- --------------------------------------------------------

--
-- Структура таблицы `category_description`
--

CREATE TABLE `category_description` (
  `category_id` int UNSIGNED NOT NULL,
  `language_id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `category_description`
--

INSERT INTO `category_description` (`category_id`, `language_id`, `title`, `description`, `keywords`, `content`) VALUES
(1, 1, 'Компьютеры', NULL, NULL, 'Компьютер — функциональное устройство, способное выполнять значительный объём вычислений, включая многочисленные арифметические и логические операции, без прямого вмешательства человека. \r\nКомпьютер может быть как отдельным блоком, так и состоять из нескольких взаимосвязанных устройств.\r\nКомпьютер представляет собой электронное устройство, которое работает с информацией и данными. \r\nОн может хранить, извлекать и обрабатывать данные. \r\nВы уже знаете, что с помощью компьютера можно печатать документы, отправлять электронную почту, играть в компьютерные игры и просматривать веб-страницы. \r\nВы можете также редактировать или создавать электронные таблицы, презентации и даже видео.'),
(1, 2, 'Computers', NULL, NULL, 'A computer is a functional device capable of performing a significant amount of calculations, including numerous arithmetic and logical operations, without direct human intervention. \r\nA computer can be either a single unit or consist of several interconnected devices.\r\nA computer is an electronic device that works with information and data. \r\nIt can store, retrieve and process data. \r\nYou already know that you can use a computer to print documents, send e-mail, play computer games, and browse the Web. \r\nYou can also edit or create spreadsheets, presentations, and even videos.'),
(2, 1, 'Планшеты', NULL, NULL, 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.'),
(2, 2, 'Tablets', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla viverra accumsan metus non ullamcorper. Nunc facilisis enim et neque dapibus, at accumsan elit fermentum. Praesent quis ante arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus interdum in tellus quis auctor. In pellentesque congue lacus sed laoreet. Duis imperdiet neque id tempor dictum. Donec volutpat felis et enim consequat, vitae vestibulum turpis eleifend. Integer eget congue lacus. Sed vitae quam tempor, gravida odio in, imperdiet leo. Aenean tincidunt enim vitae sagittis fringilla.'),
(3, 1, 'Ноутбуки', NULL, NULL, 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.'),
(3, 2, 'Notebooks', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla viverra accumsan metus non ullamcorper. Nunc facilisis enim et neque dapibus, at accumsan elit fermentum. Praesent quis ante arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus interdum in tellus quis auctor. In pellentesque congue lacus sed laoreet. Duis imperdiet neque id tempor dictum. Donec volutpat felis et enim consequat, vitae vestibulum turpis eleifend. Integer eget congue lacus. Sed vitae quam tempor, gravida odio in, imperdiet leo. Aenean tincidunt enim vitae sagittis fringilla.'),
(4, 1, 'Mac', NULL, NULL, 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.'),
(4, 2, 'Mac', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla viverra accumsan metus non ullamcorper. Nunc facilisis enim et neque dapibus, at accumsan elit fermentum. Praesent quis ante arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus interdum in tellus quis auctor. In pellentesque congue lacus sed laoreet. Duis imperdiet neque id tempor dictum. Donec volutpat felis et enim consequat, vitae vestibulum turpis eleifend. Integer eget congue lacus. Sed vitae quam tempor, gravida odio in, imperdiet leo. Aenean tincidunt enim vitae sagittis fringilla.'),
(5, 1, 'Windows', NULL, NULL, 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.'),
(5, 2, 'Windows', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla viverra accumsan metus non ullamcorper. Nunc facilisis enim et neque dapibus, at accumsan elit fermentum. Praesent quis ante arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus interdum in tellus quis auctor. In pellentesque congue lacus sed laoreet. Duis imperdiet neque id tempor dictum. Donec volutpat felis et enim consequat, vitae vestibulum turpis eleifend. Integer eget congue lacus. Sed vitae quam tempor, gravida odio in, imperdiet leo. Aenean tincidunt enim vitae sagittis fringilla.'),
(6, 1, 'Смартфоны', NULL, NULL, 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.'),
(6, 2, 'Smartphones', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla viverra accumsan metus non ullamcorper. Nunc facilisis enim et neque dapibus, at accumsan elit fermentum. Praesent quis ante arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus interdum in tellus quis auctor. In pellentesque congue lacus sed laoreet. Duis imperdiet neque id tempor dictum. Donec volutpat felis et enim consequat, vitae vestibulum turpis eleifend. Integer eget congue lacus. Sed vitae quam tempor, gravida odio in, imperdiet leo. Aenean tincidunt enim vitae sagittis fringilla.'),
(7, 1, 'Камеры', NULL, NULL, 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.'),
(7, 2, 'Cameras', NULL, NULL, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla viverra accumsan metus non ullamcorper. Nunc facilisis enim et neque dapibus, at accumsan elit fermentum. Praesent quis ante arcu. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus interdum in tellus quis auctor. In pellentesque congue lacus sed laoreet. Duis imperdiet neque id tempor dictum. Donec volutpat felis et enim consequat, vitae vestibulum turpis eleifend. Integer eget congue lacus. Sed vitae quam tempor, gravida odio in, imperdiet leo. Aenean tincidunt enim vitae sagittis fringilla.'),
(8, 1, 'Смартфоны Xiaomi', NULL, NULL, 'Смартфоны Xiaomi'),
(8, 2, 'Smartphon Xiaomi', NULL, NULL, 'Smartphon Xiaomi'),
(9, 1, 'Смартфоны Huawei', NULL, NULL, 'Смартфоны Huawei'),
(9, 2, 'Smartphon Huawei', NULL, NULL, 'Smartphon Huawei'),
(10, 1, 'Смартфоны Samsung', NULL, NULL, 'Смартфоны Samsung'),
(10, 2, 'Smartphon Samsung', NULL, NULL, 'Smartphon Samsung'),
(11, 1, 'Смартфоны iPhone', NULL, NULL, 'Смартфоны iPhone'),
(11, 2, 'Smartphon iPhone', NULL, NULL, 'Smartphon iPhone');

-- --------------------------------------------------------

--
-- Структура таблицы `content`
--

CREATE TABLE `content` (
  `id` int UNSIGNED NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `content`
--

INSERT INTO `content` (`id`, `slug`) VALUES
(1, 'about'),
(2, 'delivery'),
(3, 'contacts'),
(4, 'discounted'),
(5, 'warranty'),
(6, 'faq');

-- --------------------------------------------------------

--
-- Структура таблицы `content_description`
--

CREATE TABLE `content_description` (
  `content_id` int UNSIGNED NOT NULL,
  `language_id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `content_description`
--

INSERT INTO `content_description` (`content_id`, `language_id`, `title`, `text`, `keywords`, `description`) VALUES
(1, 1, 'О магазине', 'MV Shop – один из лидеров рынка по продаже цифровой и бытовой техники. <br />\nНаша цель изменить жизнь людей, сделав простым доступ к огромному количеству качественных и недорогих товаров, предоставляя лучший сервис. <br />\n<br />\nНаши клиенты – в центре всего, что мы делаем. <br />\nДоверие - главное. Мы строим долгосрочные отношения. <br /> \nВо всём, чем занимаемся, стремимся быть экспертами. <br />\nОткрыты для предложений и улучшений. <br />\n<br />\nСтань частью команды MV Shop.<br />\nВокруг нас люди, с которыми приятно работать и достигать амбициозных целей, мы стараемся нанимать единомышленников. <br />\n<br /><br />', 'About', 'About'),
(1, 2, 'About shop', 'MV Shop is one of the market leaders in selling digital and home appliances. <br />\nOur goal is to change people\'s lives by making it easy to access a vast array of quality and affordable products by providing the best service. <br />\n\nOur customers are at the center of everything we do <br />\nTrust is paramount. We build long-term relationships <br />\nWe strive to be experts in everything we do. <br />\nOpen to suggestions and improvements <br />\n<br /><br />\n\nBecome part of the MV Shop team. <br />\nWe are surrounded by people with whom it is pleasant to work and achieve ambitious goals, we try to hire like-minded people. <br />\n<br />', 'About', 'About'),
(2, 1, 'Доставка', 'Контент страницы доставка', 'Delivery', 'Delivery'),
(2, 2, 'Delivery', 'Content of the page delivery', 'Delivery', 'Delivery'),
(3, 1, 'Контакты', 'Контент страницы Контакты', 'Contacts', 'Contacts'),
(3, 2, 'Contacts', 'Contact page Contacts', 'Contacts', 'Contacts'),
(4, 1, 'Акции', 'Акции', 'Discounted', 'Discounted'),
(4, 2, 'Discounted', 'Discounted', 'Discounted', 'Discounted'),
(5, 1, 'Гарантия', 'Гарантия', 'Warranty', 'Warranty'),
(5, 2, 'Warranty', 'Warranty', 'Warranty', 'Warranty'),
(6, 1, 'FAQ', 'Этапы оформления заказа: <br /><br />\nШаг 1. Укажите локацию. <br />\nШаг 2. Добавьте товар в корзину. <br />\nШаг 3. Укажите данные покупателя. <br />\nШаг 4. Выберите способ получения. <br />\nШаг 5. Выберите способ оплаты. <br />\nШаг 6. Подтвердите заказ. <br />\n<br />', 'FAQ', 'FAQ'),
(6, 2, 'FAQ', 'Steps to place an order: <br /><br />\nStep 1. Specify a location. <br />\nStep 2. Add the product to the cart. <br />\nStep 3. Specify the buyer\'s details. <br />\nStep 4. Select pickup method. <br />\nStep 5. Select payment method. <br />\nStep 6. Confirm the order. <br />\n<br />', 'FAQ', 'FAQ');

-- --------------------------------------------------------

--
-- Структура таблицы `language`
--

CREATE TABLE `language` (
  `id` int UNSIGNED NOT NULL,
  `code` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `base` tinyint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `language`
--

INSERT INTO `language` (`id`, `code`, `title`, `base`) VALUES
(1, 'ru', 'Русский', 1),
(2, 'en', 'English', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `product`
--

CREATE TABLE `product` (
  `id` int UNSIGNED NOT NULL,
  `category_id` int UNSIGNED NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double NOT NULL DEFAULT '0',
  `old_price` double NOT NULL DEFAULT '0',
  `status` tinyint NOT NULL DEFAULT '1',
  `hit` tinyint NOT NULL DEFAULT '0',
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'uploads/no_image.jpg',
  `is_download` tinyint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `product`
--

INSERT INTO `product` (`id`, `category_id`, `slug`, `price`, `old_price`, `status`, `hit`, `img`, `is_download`) VALUES
(1, 7, 'canon-eos-5d', 4500, 12, 1, 1, '/uploads/img/products/canon-eos.jpg', 0),
(2, 1, 'apple-led-cinema-27', 2500, 0, 1, 1, '/uploads/img/products/apple-27-inch-led-cinema.jpg', 0),
(3, 1, 'imac', 3600, 0, 1, 1, '/uploads/img/products/apple-imac-21.jpg', 0),
(4, 11, 'iphone', 1600, 0, 1, 1, '/uploads/img/products/iphone_1.jpg', 0),
(5, 5, 'notebook-msi-creatorpro-x18-hx-a14vmg', 2450, 0, 1, 1, '/uploads/img/products/notebook-msi-creatorpro-x18-hx-a14vmg.jpg', 0),
(6, 5, 'notebook-msi-creator-16-ai-a1vig-060ru', 1950, 0, 1, 0, '/uploads/img/products/notebook-msi-creator-16-ai-a1vig.jpg', 0),
(7, 5, 'notebook-xiaomi-mi-pro-15', 1850, 0, 1, 1, '/uploads/img/products/notebook-xiaomi-mi-pro-15.jpg', 0),
(8, 1, 'kompyuter-3', 4300, 0, 1, 0, '/uploads/img/products/kompyuter-3.jpg', 0),
(9, 1, 'kompyuter-4', 4400, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(10, 1, 'kompyuter-5', 4500, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(11, 1, 'kompyuter-6', 4600, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(12, 1, 'kompyuter-7', 4700, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(13, 1, 'kompyuter-8', 4800, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(14, 1, 'kompyuter-9', 4900, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(15, 1, 'kompyuter-10', 5010, 0, 1, 0, '/assets/img/products/no_image.jpg', 0),
(16, 10, 'smartphon_samsung_galaxy_s25', 1200, 0, 1, 0, '/uploads/img/products/smartphon_samsung_galaxy_s25.jpg', 0),
(17, 5, 'notebook-xiaomi-mi-laptop-redmibook-16', 2050, 0, 1, 1, '/uploads/img/products/notebook-xiaomi-mi-pro-15.jpg', 0),
(18, 5, 'notebook-huawei-matebook-d-16', 1750, 0, 1, 0, 'uploads/no_image.jpg', 0),
(19, 4, 'notebook-apple-macbook-pro-a3186', 4850, 0, 1, 0, '/uploads/img/products/notebook-apple-macbook-pro-a3186.jpg', 0),
(20, 2, 'tablet-samsung-galaxy-tab-s10-ultra-bsm-x926b', 850, 0, 1, 0, '/uploads/img/products/tablet-samsung-galaxy-tab-s10-ultra-bsm-x926b.jpg', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `product_description`
--

CREATE TABLE `product_description` (
  `product_id` int UNSIGNED NOT NULL,
  `language_id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exerpt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `keywords` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reviews` int UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `product_description`
--

INSERT INTO `product_description` (`product_id`, `language_id`, `title`, `content`, `exerpt`, `keywords`, `description`, `reviews`) VALUES
(1, 1, 'Canon EOS 5D', '<p>Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия. По своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.</p>', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать', NULL, NULL, 42),
(1, 2, 'Canon EOS 5D', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit. Ut imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.</p>', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 35),
(2, 1, 'Apple LED Cinema Display 27″', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать', NULL, NULL, 52),
(2, 2, 'Apple LED Cinema Display 27″', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 76),
(3, 1, 'Apple iMac 21,5\" Retina 4K, 6C i5', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать', NULL, NULL, 63),
(3, 2, 'Apple iMac 21,5\" Retina 4K, 6C i5', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 7),
(4, 1, 'iPhone', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать', NULL, NULL, 4),
(4, 2, 'iPhone', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 2),
(5, 1, 'Notebook MSI CreatorPro X18 HX A14VMG 18\"', 'Notebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.\r\nNotebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.\r\nNotebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.\r\nNotebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.', 'Notebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.', NULL, NULL, 77),
(5, 2, 'Notebook MSI CreatorPro X18 HX A14VMG 18\"', 'Notebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.\r\nNotebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. \r\nEtiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. \r\nDonec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. \r\nInteger vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. \r\nCras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. \r\nDuis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. \r\nSuspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. \r\nSed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. \r\nNam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. \r\nSed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. \r\nIn hac habitasse platea dictumst. \r\nCras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.\r\n', 'Notebook MSI CreatorPro X18 HX A14VMG-415RU 18\", IPS, Intel Core i9 14900HX 2.2ГГц, 24-core, RAM 64ГБ DDR5, 2ТБ + 2ТБ SSD, NVIDIA RTX A5000 - 16 ГБ.', NULL, NULL, 77),
(6, 1, 'Notebook MSI Creator 16 AI Studio A1VIG-060RU 16\"', 'Ноутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.\r\nНоутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.\r\nНоутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.\r\nНоутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.\r\nНоутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.', 'Ноутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.', NULL, NULL, 59),
(6, 2, 'Notebook MSI Creator 16 AI Studio A1VIG-060RU 16\"', 'Ноутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.\r\nНоутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. \r\nEtiam at ligula bibendum, sollicitudin mi ac, auctor urna. \r\nNulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. \r\nVivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. \r\nFusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. \r\nSuspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. \r\nAenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Ноутбук MSI Creator 16 AI Studio A1VIG-060RU 16\", IPS, Intel Core Ultra 9 185H 2.3ГГц, 16-core, 64ГБ DDR5, 2ТБ SSD, NVIDIA GeForce RTX 4090 - 16 ГБ, Windows 11 Pro.', NULL, NULL, 59),
(7, 1, 'Ноутбук Xiaomi Mi Pro 15\"', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 38),
(7, 2, 'Notebook Xiaomi Mi Pro 15\"', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 59),
(8, 1, 'Компьютер 3', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 21),
(8, 2, 'Computer 3', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 11),
(9, 1, 'Компьютер 4', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 69),
(9, 2, 'Computer 4', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 73),
(10, 1, 'Компьютер 5', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 77),
(10, 2, 'Computer 5', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 7),
(11, 1, 'Компьютер 6', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 44),
(11, 2, 'Computer 6', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 38),
(12, 1, 'Компьютер 7', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 60),
(12, 2, 'Computer 7', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 26),
(13, 1, 'Компьютер 8', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 29),
(13, 2, 'Computer 8', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 66),
(14, 1, 'Компьютер 9', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 3),
(14, 2, 'Computer 9', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 59),
(15, 1, 'Компьютер 10', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать несколько абзацев более менее осмысленного текста рыбы на русском языке, а начинающему оратору отточить навык публичных выступлений в домашних условиях. При создании генератора мы использовали небезизвестный универсальный код речей. Текст генерируется абзацами случайным образом от двух до десяти предложений в абзаце, что позволяет сделать текст более привлекательным и живым для визуально-слухового восприятия.\r\nПо своей сути рыбатекст является альтернативой традиционному lorem ipsum, который вызывает у некторых людей недоумение при попытках прочитать рыбу текст. В отличии от lorem ipsum, текст рыба на русском языке наполнит любой макет непонятным смыслом и придаст неповторимый колорит советских времен.', 'Сайт рыбатекст поможет дизайнеру, верстальщику, вебмастеру сгенерировать ', NULL, NULL, 46),
(15, 2, 'Computer 10', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam at ligula bibendum, sollicitudin mi ac, auctor urna. Nulla vulputate orci fermentum ante pretium blandit ut sed libero. Donec non feugiat turpis, et faucibus est. Vivamus lacus elit, ornare ultrices accumsan sed, pretium quis velit. Integer vel scelerisque odio. Vestibulum id dignissim urna. Fusce vitae urna vel magna dictum hendrerit in eget quam. Cras convallis metus enim, a iaculis metus scelerisque at. Vivamus vel ultricies est. Vivamus imperdiet tempor suscipit. Duis nibh sapien, feugiat a sagittis at, blandit vitae nulla. Sed rutrum vehicula fringilla. Praesent pretium elementum elit.\r\nUt imperdiet sem vel tempor molestie. Maecenas convallis tortor a tincidunt egestas. In ultrices ornare suscipit. Suspendisse consequat eu felis et mollis. Aliquam viverra gravida est, sit amet venenatis arcu porttitor a. Sed maximus placerat sapien, nec fermentum quam luctus nec. Aenean semper ultrices urna eu fermentum. Nam at leo scelerisque, fermentum leo a, egestas odio. Fusce tincidunt magna mi, non pharetra neque egestas a. Sed sagittis vel nunc sed scelerisque. Pellentesque vestibulum quam ultrices fermentum maximus. In hac habitasse platea dictumst. Cras sit amet ornare mi, at efficitur libero. Morbi venenatis sapien a euismod finibus.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit', NULL, NULL, 53),
(16, 1, 'Смартфон Samsung Galaxy S25 Ultra 512GB Titanium Zwart', 'Смартфон Samsung Galaxy S25 Ultra 512GB Titanium Zwart.', 'Смартфон Samsung Galaxy S25 Ultra 512GB Titanium Zwart. Смартфон Samsung Galaxy S25 Ultra 512GB Titanium Zwart. Смартфон Samsung Galaxy S25 Ultra 512GB Titanium Zwart.', NULL, NULL, 99),
(16, 2, 'Smartphon Samsung Galaxy S25 Ultra 512GB Titanium Zwart', 'Smartphon Samsung Galaxy S25 Ultra 512GB Titanium Zwart.', 'Smartphon Samsung Galaxy S25 Ultra 512GB Titanium Zwart. Smartphon Samsung Galaxy S25 Ultra 512GB Titanium Zwart. Smartphon Samsung Galaxy S25 Ultra 512GB Titanium Zwart.', NULL, NULL, 99),
(17, 1, 'Ноутбук Xiaomi Laptop Redmibook 16', 'Xiaomi Laptop 2024 Redmibook 16 Intel Core i5-12450H Intel UHD Grafische 16GB DDR5 + 1TB/512G SSD 16 inch 60Hz Notebook PC', 'Xiaomi Laptop 2024 Redmibook 16 Intel Core i5-12450H Intel UHD Grafische 16GB DDR5 + 1TB/512G SSD 16 inch 60Hz Notebook PC', NULL, NULL, 105),
(17, 2, 'Notebook Xiaomi Laptop Redmibook 16', 'Xiaomi Laptop 2024 Redmibook 16 Intel Core i5-12450H Intel UHD Grafische 16GB DDR5 + 1TB/512G SSD 16 inch 60Hz Notebook PC', 'Xiaomi Laptop 2024 Redmibook 16 Intel Core i5-12450H Intel UHD Grafische 16GB DDR5 + 1TB/512G SSD 16 inch 60Hz Notebook PC', NULL, NULL, 105),
(18, 1, 'Ноутбук Huawei MateBook D 16\" IPS Intel Core i5 12450H', 'Notebook Huawei MateBook D 16\", IPS, Intel Core i5 12450H 2ГГц, 8-core, RAM 16ГБ, 1ТБ SSD, Intel UHD Graphics', 'Notebook Huawei MateBook D 16\", IPS, Intel Core i5 12450H 2ГГц, 8-core, RAM 16ГБ, 1ТБ SSD, Intel UHD Graphics', NULL, NULL, 52),
(18, 2, 'Notebook Huawei MateBook D 16\" IPS Intel Core i5 12450H', 'Notebook Huawei MateBook D 16\", IPS, Intel Core i5 12450H 2ГГц, 8-core, RAM 16ГБ, 1ТБ SSD, Intel UHD Graphics', 'Notebook Huawei MateBook D 16\", IPS, Intel Core i5 12450H 2ГГц, 8-core, RAM 16ГБ, 1ТБ SSD, Intel UHD Graphics', NULL, NULL, 52),
(19, 1, 'Notebook Apple MacBook Pro A3186 16.2\"', 'Ноутбук Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\nНоутбук Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\nНоутбук Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\nНоутбук Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\n', 'Ноутбук Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]', NULL, NULL, 80),
(19, 2, 'Notebook Apple MacBook Pro A3186 16.2\"', 'Notebook Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\nNotebook Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\nNotebook Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\nNotebook Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]\r\n', 'Notebook Apple MacBook Pro A3186 16.2\", Retina XDR, Apple M4 Max 16 core 4ГГц, 16-core, 48ГБ 1ТБ SSD, macOS, [mx313hn/a]', NULL, NULL, 80),
(20, 1, 'Tablet Samsung Galaxy Tab S10 Ultra BSM-X926B', 'Планшет Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, стилус, серебристый [sm-x926bzstcau]\r\nПланшет Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, стилус, серебристый [sm-x926bzstcau]\r\nПланшет Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, стилус, серебристый [sm-x926bzstcau]\r\nПланшет Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, стилус, серебристый [sm-x926bzstcau]\r\n', 'Планшет Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, стилус, серебристый [sm-x926bzstcau]', NULL, NULL, 10),
(20, 2, 'Tablet Samsung Galaxy Tab S10 Ultra BSM-X926B', 'Tablet Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, stylus, silver [sm-x926bzstcau]\r\nTablet Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, stylus, silver [sm-x926bzstcau]\r\nTablet Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, stylus, silver [sm-x926bzstcau]\r\nTablet Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, stylus, silver [sm-x926bzstcau]\r\n', 'Tablet Samsung Galaxy Tab S10 Ultra BSM-X926B 16/1024 GB 9300+ 5G, 2960 x 1848, 120Гц, Android 14, stylus, silver [sm-x926bzstcau]\r\n', NULL, NULL, 10);

-- --------------------------------------------------------

--
-- Структура таблицы `product_gallery`
--

CREATE TABLE `product_gallery` (
  `id` int UNSIGNED NOT NULL,
  `product_id` int UNSIGNED NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `product_gallery`
--

INSERT INTO `product_gallery` (`id`, `product_id`, `img`) VALUES
(1, 1, '/uploads/img/products/canon-eos.jpg'),
(2, 1, '/uploads/img/products/canon-eos.jpg'),
(3, 1, '/uploads/img/products/canon-eos.jpg'),
(4, 2, '/uploads/img/products/apple-27-inch-led-cinema.jpg'),
(5, 2, '/uploads/img/products/apple-27-inch-led-cinema.jpg'),
(6, 2, '/uploads/img/products/apple-27-inch-led-cinema.jpg'),
(7, 3, '/uploads/img/products/apple-imac-21.jpg'),
(8, 3, '/uploads/img/products/apple-imac-21.jpg'),
(9, 3, '/uploads/img/products/apple-imac-21.jpg'),
(10, 4, '/uploads/img/products/iphone_1.jpg'),
(11, 4, '/uploads/img/products/iphone_1.jpg'),
(12, 4, '/uploads/img/products/iphone_1.jpg'),
(13, 7, '/uploads/img/products/notebook-xiaomi-mi-pro-15.jpg'),
(14, 7, '/uploads/img/products/notebook-xiaomi-mi-pro-15.jpg'),
(15, 7, '/uploads/img/products/notebook-xiaomi-mi-pro-15.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `slider`
--

CREATE TABLE `slider` (
  `id` int UNSIGNED NOT NULL,
  `img` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `slider`
--

INSERT INTO `slider` (`id`, `img`) VALUES
(1, '/assets/images/slider/slider_1.jpg'),
(2, '/assets/images/slider/slider_2.jpg'),
(3, '/assets/images/slider/slider_3.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` enum('user','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `name`, `lastname`, `address`, `role`) VALUES
(1, 'info@gmail.net', '$2y$10$mwYzJKrEP.NUGCwLtsQQeOdC5jeXlffD0RUypDE6M.NASTExLJiCS', 'Ivan', 'Ivanov', 'Moscow', 'user'),
(3, 'info2@gmail.net', '$2y$10$mwYzJKrEP.NUGCwLtsQQeOdC5jeXlffD0RUypDE6M.NASTExLJiCS', 'Ivan2', 'Ivanov', 'Moscow', 'user'),
(4, 'info3@gmail.net', '$2y$10$mwYzJKrEP.NUGCwLtsQQeOdC5jeXlffD0RUypDE6M.NASTExLJiCS', 'Ivan3', 'Ivanov', 'Moscow', 'user'),
(5, 'info4@gmail.net', '$2y$10$AkKBcTeV6SE/vzSx8ctzk.ZNk0N49LuZHtDjdIUtY4CGV66RaHMgS', 'Ivan4', NULL, 'Адрес4', 'user'),
(6, 'info5@gmail.net', '$2y$10$1wmiOFPqI7wtMsw8m05QwuWGUtvjLDnNKAkgik8Xx5MEi1rD4jE3K', 'Ivan5', 'Ivanov', 'Moscow', 'user');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`(191));

--
-- Индексы таблицы `category_description`
--
ALTER TABLE `category_description`
  ADD PRIMARY KEY (`category_id`,`language_id`);

--
-- Индексы таблицы `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`(191));

--
-- Индексы таблицы `content_description`
--
ALTER TABLE `content_description`
  ADD PRIMARY KEY (`content_id`,`language_id`);

--
-- Индексы таблицы `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`(191));

--
-- Индексы таблицы `product_description`
--
ALTER TABLE `product_description`
  ADD PRIMARY KEY (`product_id`,`language_id`);

--
-- Индексы таблицы `product_gallery`
--
ALTER TABLE `product_gallery`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `category`
--
ALTER TABLE `category`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT для таблицы `content`
--
ALTER TABLE `content`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `language`
--
ALTER TABLE `language`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `product`
--
ALTER TABLE `product`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT для таблицы `product_gallery`
--
ALTER TABLE `product_gallery`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
